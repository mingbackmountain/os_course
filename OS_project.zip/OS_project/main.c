//6088109
//6088133
#include <stdio.h>
#include <sys/time.h>
#include <inttypes.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

//Variable Declaration
int N;
int M;
int E;
int T;

///Define the Limit for number of robot and simulation
#define ROBOT_LIMIT 100
#define SIM_LIMIT 100

//Define robot state
#define learning 2
#define helping 1
#define want 0

//Define neighbor robot
#define LEFT (robot_id != 0 ? (robot_id - 1) % N : N - 1)
#define RIGHT (robot_id + 1) % N

//starting time
struct timespec start;

//semaphore for simulators
sem_t *simulators;

//Define array of learning Time,status of robot,number of report
int *learning_Time;
int *robot_state;
int *report_count;
pthread_mutex_t server_lock;

//get the current time
uint64_t getTime()
{
    struct timespec current_time;
    clock_gettime(CLOCK_MONOTONIC_RAW, &current_time);
    return (current_time.tv_sec - start.tv_sec) * 1000000 + (current_time.tv_nsec - start.tv_nsec) / 1000;
}

//Check wheather LEFT robot and RIGHT robot are ready to help or not?
bool check_neighbor(int robot_id)
{
    if (robot_state[robot_id] != helping && robot_state[LEFT] != learning && robot_state[RIGHT] != learning)
    {
        robot_state[robot_id] = learning;
        robot_state[LEFT] = helping;
        robot_state[RIGHT] = helping;
        return true;
    }
    return false;
}

//Finish learning and upadate to the master server
void DoneLearning(int robot_id)
{
    printf("DONE[%" PRIu64 "]: %d, %d, %d\n", getTime(), robot_id, LEFT, RIGHT);
    fflush(stdout);

    pthread_mutex_lock(&server_lock);
    learning_Time[robot_id] += E;
    report_count[robot_id] += 1;
    printf("UPDATE[%" PRIu64 "]: %d, %d\n", getTime(), robot_id, report_count[robot_id]);
    pthread_mutex_unlock(&server_lock);

    robot_state[robot_id] = want;
    robot_state[LEFT] = want;
    robot_state[RIGHT] = want;
}

//Learning
void Learning(int robot_id)
{
    if (robot_state[LEFT] == want && robot_state[RIGHT] == want && robot_state[robot_id] == want)
    {
        sem_wait(simulators);
        if (check_neighbor(robot_id))
        {

            printf("LEARN[%" PRIu64 "]: %d, %d, %d\n", getTime(), robot_id, LEFT, RIGHT);
            fflush(stdout);
            sleep(E);
            DoneLearning(robot_id);
        }
        sem_post(simulators);
    }
}

//routine of the robot in order to aquire the simulator and start learning
void *robotAct(void *id)
{
    int robot_id = *(int *)id;
    while (1)
    {
        Learning(robot_id);
    }
}

//function for produce the report
void getReport()
{
    int total_report = 0;
    for (int i = 0; i < N; i++)
    {
        printf("%d: %d, %d\n", i, learning_Time[i], report_count[i]);
        total_report += report_count[i];
    }
    printf("MASTER: %d", total_report);
}

int main(int argc, char *argv[])
{
    //initialize the start time
    clock_gettime(CLOCK_MONOTONIC_RAW, &start);

    //getting input
    N = atoi(argv[1]);
    M = atoi(argv[2]);
    E = atoi(argv[3]);
    T = atoi(argv[4]);

    //Initialize the robot thread and necessary variable
    pthread_t robot_id[N];
    int robots[N];
    learning_Time = (int *)malloc(sizeof(int) * N);
    robot_state = (int *)malloc(sizeof(int) * N);
    report_count = (int *)malloc(sizeof(int) * N);

    //check limit of robot
    if (N > ROBOT_LIMIT || N < 3)
    {
        printf("ERROR Robot input");
        return -1;
    }
    //check limit of simulation
    if (M > SIM_LIMIT)
    {
        printf("ERROR simulator input");
    }

    //Initialize simulator semaphore
    simulators = sem_open("/sim", O_CREAT, 0666, M);
    sem_close(simulators);
    sem_unlink("/sim");
    simulators = sem_open("/sim", O_CREAT, 0666, M);
    srand(time(NULL));
    //creat robot thread
    for (int i = 0; i < N; i++)
    {
        robots[i] = i;
        robot_state[i] = want;
        learning_Time[i] = 0;
        report_count[i] = 0;
        pthread_create(&robot_id[i], NULL, robotAct, &robots[i]);
    }

    //Limit running program
    sleep(T);

    //cancel the robot thread
    for (int i = 0; i < N; i++)
    {
        pthread_cancel(robot_id[i]);
    }

    //closing the semaphore
    sem_close(simulators);
    sem_unlink("/fortytwo");
    //getting the report
    getReport();
    return 0;
}