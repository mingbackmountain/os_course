Thanakorn Pasangthien 6088109 Section 1
Arada Puengmongkolchaikit 6088133 Section 1

We both exchange the ideas of how to tackle the problem together. For example, we have discuss how to solve the dining philosopher problem and use that logic into our code. Furthermore, we expand upon the idea and come up with our own solution for the project.

Thanakorn 
	- responsible for
		- main 
		- check_neighbor
		- Learning
		- getTime
Arada
	- responsible for the 
		-Error Checking
		-robotAct
		-DoneLearning
		-getReport
		

After we done all of these function, we have revise and modify the source code together in order to produce the suitable output of the project.